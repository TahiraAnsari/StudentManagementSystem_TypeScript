import inquirer from "inquirer";

console.log('Student Management System');

const randomNumber: number = Math.floor(10000 + Math.random() * 90000)

let myBalance: number = 0

let answer = await inquirer.prompt(
  [
    {
      name: "students",
      message: "Enter Student name:",
      type: "input",
      validate: function(value){
        if(value.trim() !== ""){
          return true;
        }
        return "Please Enter a non-empty value.";
      },
    },
    {
      name: "course",
      type: "list",
      message: "Select the Course to Enrolled",
      choices: ["MS Office", "HTML", "JavaScript", "TypeScript", "Python"]
    }
  ]
);

const tuitionFee: {[ket: string]: number} = {
  "MS Office": 2000,
  "HTML": 2500,
  "JavaScript": 5000,
  "TypeScript": 6000,
  "Python": 10000
};

console.log(`\nTuition Fee: ${answer.course} Rs:${tuitionFee[answer.course]} /-\n`);
console.log(`Balance: ${myBalance}\n`);

let paymentType = await inquirer.prompt(
  [
    {
      name: "payment",
      type: "list",
      message: "Select payment method",
      choices: ["Bank Transfer", "Easypaisa", "Jazzcash"]
    },
    {
      name: "amount",
      type: "input",
      message: "Transfer Money",
      validate: function(value){
        if(value.trim() !== ""){
          return true;
        }
        return "Please Enter a non-empty value.";
      },
    }
  ]
);

console.log(`\nYou Select payment method ${paymentType.payment}\n`);

const TuitionFee = tuitionFee[answer.course];
const paymentAmount = parseFloat(paymentType.amount);

if(TuitionFee === paymentAmount){
  console.log(`Congratulations, you have Successfully Enrolled in ${answer.course}.\n`);

  let ans = await inquirer.prompt(
    [
      {
        name: "select",
        type: "list",
        message: "What would you like to do next",
        choices: ["View Status", "Exit"]
      }
    ]);
  
    if(ans.select === "View Status"){
      console.log("\n*************Status*************");
      console.log();
      console.log(`\tStudent Name: ${answer.students}`);
      console.log(`\tStudnet ID: ${randomNumber}`);
      console.log(`\tCourse: ${answer.course}`);
      console.log(`\tTuition Fee Paid: ${paymentAmount}`);
      console.log(`\tBalance: ${myBalance += paymentAmount}`);
    }
    else{
      console.log("\nExiting Student Management System\n");
    }  
}else{
  console.log("Invalid amount due to course\n");
  
}

 
    